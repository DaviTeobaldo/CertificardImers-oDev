function muda(){
  document.body.classList.toggle("dark");
}